#!/bin/bash
# ----- [2026-02-26] 컨테이너 알람 로그 기록 스크립트 -----
# 기능:
#   1. watchdog.conf에서 감시 대상 컨테이너 목록 로드
#   2. 각 컨테이너의 현재 상태를 podman inspect로 확인
#   3. 이전 상태(alert_state/*.state)와 비교하여 상태 변화 감지
#   4. 상태 변화 시 알람 로그 기록 (logs/alert.log)
#      - running → stopped/exited/dead: [FIRING] 알람
#      - stopped → running: [RESOLVED] 복구
#   5. Prometheus textfile 메트릭 생성 (podman_alerts.prom)
#      → Node Exporter → Prometheus → Grafana 대시보드
#
# 실행: cron으로 매 1분 실행
#   * * * * * /home/chatpro/monitoring/alert_logger.sh
#
# 데이터 흐름:
#   alert_logger.sh → logs/alert.log (사람이 읽는 알람 로그)
#   alert_logger.sh → node-exporter/textfile/podman_alerts.prom (Grafana 메트릭)
#   Node Exporter → Prometheus 수집 → Grafana 대시보드 표시

# ============================================
# 설정
# ============================================
MONITORING_DIR="/home/chatpro/monitoring"
CONF_FILE="${MONITORING_DIR}/watchdog.conf"
LOG_DIR="${MONITORING_DIR}/logs"
LOG_FILE="${LOG_DIR}/alert.log"
STATE_DIR="${LOG_DIR}/alert_state"
METRICS_FILE="${MONITORING_DIR}/node-exporter/textfile/podman_alerts.prom"

HOSTNAME=$(hostname)
# [2026.02.25] 192.168.122.x 대역 IP 사용 (enp1s0 인터페이스)
SERVER_IP=$(ip -4 addr show enp1s0 2>/dev/null | grep -oP '192\.168\.122\.\d+' | head -1)
if [ -z "$SERVER_IP" ]; then
    SERVER_IP=$(hostname -I | awk '{print $1}')
fi

NOW=$(date '+%Y-%m-%d %H:%M:%S')
NOW_EPOCH=$(date +%s)

# ============================================
# 초기화
# ============================================
mkdir -p "$LOG_DIR" "$STATE_DIR"

# ============================================
# 감시 대상 컨테이너 목록 로드 (watchdog.conf 재사용)
# ============================================
if [ -f "$CONF_FILE" ]; then
    WATCH_CONTAINERS=$(grep -v '^\s*#' "$CONF_FILE" | grep -v '^\s*$' | tr -d ' ' | tr '\n' ' ')
else
    WATCH_CONTAINERS="sdc-open-webui sdc-redis-dev sdc-pipelines sdc-guardrails sdc-monitoring"
fi

# ============================================
# 로그 함수
# ============================================
log_alert() {
    local level=$1    # FIRING / RESOLVED / INFO
    local severity=$2  # critical / warning / info
    local container=$3
    local message=$4
    echo "[${NOW}] [${level}] [${severity}] ${container} - ${message}" >> "$LOG_FILE"
}

# ============================================
# 메인: 컨테이너 상태 비교 및 알람 감지
# ============================================
firing_count=0
resolved_count=0

# 각 컨테이너의 현재 알람 상태를 추적하는 임시 배열 (메트릭 생성용)
declare -A ALERT_STATUS        # 컨테이너별 현재 알람 상태 (1=firing, 0=ok)
declare -A LAST_FIRED_EPOCH    # 컨테이너별 마지막 알람 발생 시각

for container in $WATCH_CONTAINERS; do
    STATE_FILE="${STATE_DIR}/${container}.state"
    FIRED_FILE="${STATE_DIR}/${container}.fired_at"

    # 현재 상태 확인
    current_state=$(podman inspect --format '{{.State.Status}}' "$container" 2>/dev/null)

    # 컨테이너가 존재하지 않으면 건너뛰기
    if [ -z "$current_state" ]; then
        ALERT_STATUS[$container]=0
        continue
    fi

    # 이전 상태 읽기
    if [ -f "$STATE_FILE" ]; then
        prev_state=$(cat "$STATE_FILE")
    else
        prev_state="unknown"
    fi

    # 마지막 알람 발생 시각 읽기
    if [ -f "$FIRED_FILE" ]; then
        LAST_FIRED_EPOCH[$container]=$(cat "$FIRED_FILE")
    else
        LAST_FIRED_EPOCH[$container]=0
    fi

    # 상태 변화 감지
    if [ "$current_state" != "$prev_state" ]; then
        case "$current_state" in
            running)
                # 복구됨 (stopped/exited/dead → running)
                if [ "$prev_state" != "unknown" ]; then
                    log_alert "RESOLVED" "info" "$container" "컨테이너 복구됨 (${prev_state} → running)"
                    resolved_count=$((resolved_count + 1))
                fi
                ALERT_STATUS[$container]=0
                ;;
            exited|dead|stopped)
                # 중지됨 (running → stopped/exited/dead)
                log_alert "FIRING" "critical" "$container" "컨테이너 중지 감지 (${prev_state} → ${current_state})"
                firing_count=$((firing_count + 1))
                ALERT_STATUS[$container]=1
                LAST_FIRED_EPOCH[$container]=$NOW_EPOCH
                echo "$NOW_EPOCH" > "$FIRED_FILE"
                ;;
            *)
                # 기타 상태 변화
                log_alert "INFO" "warning" "$container" "상태 변경 (${prev_state} → ${current_state})"
                ALERT_STATUS[$container]=0
                ;;
        esac
    else
        # 상태 변화 없음 - 현재 상태가 중지 상태이면 계속 firing
        case "$current_state" in
            exited|dead|stopped)
                ALERT_STATUS[$container]=1
                ;;
            *)
                ALERT_STATUS[$container]=0
                ;;
        esac
    fi

    # 현재 상태를 저장 (다음 실행 시 비교용)
    echo "$current_state" > "$STATE_FILE"
done

# ============================================
# [2026-02-26] 활성 알람 파일 생성 (미해소 알람만 유지)
# - 알람 발생 시 추가, 해소 시 삭제
# - 현재 firing 중인 알람만 이 파일에 남아있음
# ============================================
ACTIVE_FILE="${LOG_DIR}/alert_active.log"
ACTIVE_TMP="${ACTIVE_FILE}.tmp"

{
for container in $WATCH_CONTAINERS; do
    if [ "${ALERT_STATUS[$container]}" = "1" ]; then
        # firing 중인 컨테이너: 발생 시각 읽기
        fired_at=${LAST_FIRED_EPOCH[$container]:-$NOW_EPOCH}
        fired_time=$(date -d @${fired_at} '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "$NOW")
        current_state=$(cat "${STATE_DIR}/${container}.state" 2>/dev/null || echo "unknown")
        echo "[${fired_time}] [FIRING] [critical] ${container} - 상태: ${current_state} (미해소)"
    fi
done
} > "$ACTIVE_TMP"

mv "$ACTIVE_TMP" "$ACTIVE_FILE"

# ============================================
# Prometheus 메트릭 생성
# ============================================
TMP_FILE="${METRICS_FILE}.tmp"

{
# 컨테이너별 알람 상태
echo "# HELP podman_alert_firing Container alert firing state (1=firing/down, 0=ok/running)"
echo "# TYPE podman_alert_firing gauge"
for container in $WATCH_CONTAINERS; do
    alert_val=${ALERT_STATUS[$container]:-0}
    echo "podman_alert_firing{name=\"${container}\",host=\"${HOSTNAME}\",server_ip=\"${SERVER_IP}\"} ${alert_val}"
done

# 전체 firing 알람 수
total_firing=0
for container in $WATCH_CONTAINERS; do
    if [ "${ALERT_STATUS[$container]}" = "1" ]; then
        total_firing=$((total_firing + 1))
    fi
done
echo "# HELP podman_alert_firing_total Total number of currently firing container alerts"
echo "# TYPE podman_alert_firing_total gauge"
echo "podman_alert_firing_total{host=\"${HOSTNAME}\",server_ip=\"${SERVER_IP}\"} ${total_firing}"

# 컨테이너별 마지막 알람 발생 시각
echo "# HELP podman_alert_last_fired_timestamp Timestamp of last alert firing for each container"
echo "# TYPE podman_alert_last_fired_timestamp gauge"
for container in $WATCH_CONTAINERS; do
    fired_epoch=${LAST_FIRED_EPOCH[$container]:-0}
    echo "podman_alert_last_fired_timestamp{name=\"${container}\",host=\"${HOSTNAME}\",server_ip=\"${SERVER_IP}\"} ${fired_epoch}"
done

# 이번 실행의 이벤트 카운트
echo "# HELP podman_alert_events_in_last_run Alert events detected in last run (firing + resolved)"
echo "# TYPE podman_alert_events_in_last_run gauge"
echo "podman_alert_events_in_last_run{host=\"${HOSTNAME}\",server_ip=\"${SERVER_IP}\",type=\"firing\"} ${firing_count}"
echo "podman_alert_events_in_last_run{host=\"${HOSTNAME}\",server_ip=\"${SERVER_IP}\",type=\"resolved\"} ${resolved_count}"

# 마지막 실행 시각
echo "# HELP podman_alert_logger_last_run_timestamp Last alert_logger execution timestamp"
echo "# TYPE podman_alert_logger_last_run_timestamp gauge"
echo "podman_alert_logger_last_run_timestamp{host=\"${HOSTNAME}\",server_ip=\"${SERVER_IP}\"} ${NOW_EPOCH}"
} > "$TMP_FILE"

mv "$TMP_FILE" "$METRICS_FILE"

# ============================================
# 로그 로테이션 (10000줄 초과 시 잘라내기)
# ============================================
if [ -f "$LOG_FILE" ]; then
    line_count=$(wc -l < "$LOG_FILE")
    if [ "$line_count" -gt 10000 ]; then
        tail -5000 "$LOG_FILE" > "${LOG_FILE}.tmp"
        mv "${LOG_FILE}.tmp" "$LOG_FILE"
        log_alert "INFO" "info" "SYSTEM" "로그 파일 정리 (${line_count}줄 → 5000줄)"
    fi
fi
