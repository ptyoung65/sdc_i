#!/bin/bash
################################################################################
# Podman Watchdog & Metrics cron 자동 등록 스크립트
#
# 기능:
#   1. 필요한 디렉토리 자동 생성
#   2. 스크립트 실행 권한 설정
#   3. cron 중복 등록 방지 (이미 등록된 경우 간격만 업데이트)
#   4. 등록 결과 검증
#   5. Watchdog 실행 간격 변경 지원
#   6. 감시 대상 컨테이너 관리 (추가/제거/목록)
#   7. suppress 관리 (수동 stop 시 자동 재시작 방지)
#
# 사용법:
#   ./setup-watchdog-cron.sh                    # 설치 (기본 2분 간격)
#   ./setup-watchdog-cron.sh install --interval 3   # 3분 간격으로 설치
#   ./setup-watchdog-cron.sh interval 5         # 기존 간격을 5분으로 변경
#   ./setup-watchdog-cron.sh remove             # 제거
#   ./setup-watchdog-cron.sh status             # 상태 확인
#   ./setup-watchdog-cron.sh add <컨테이너명>       # 감시 대상 추가
#   ./setup-watchdog-cron.sh del <컨테이너명>       # 감시 대상 제거
#   ./setup-watchdog-cron.sh list               # 감시 대상 목록
#   ./setup-watchdog-cron.sh suppress <컨테이너명>  # 자동 재시작 방지
#   ./setup-watchdog-cron.sh unsuppress <컨테이너명> # 자동 재시작 방지 해제
################################################################################

set -e

# 색상
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# 경로 설정
MONITORING_DIR="/home/chatpro/monitoring"
WATCHDOG_SCRIPT="${MONITORING_DIR}/podman_watchdog.sh"
METRICS_SCRIPT="${MONITORING_DIR}/podman_metrics.sh"
ALERT_LOGGER_SCRIPT="${MONITORING_DIR}/alert_logger.sh"
LOG_DIR="${MONITORING_DIR}/logs"
COOLDOWN_DIR="${LOG_DIR}/cooldown"
SUPPRESS_DIR="${LOG_DIR}/suppress"
ALERT_STATE_DIR="${LOG_DIR}/alert_state"
TEXTFILE_DIR="${MONITORING_DIR}/node-exporter/textfile"
CONF_FILE="${MONITORING_DIR}/watchdog.conf"

# 기본 Watchdog 간격 (분)
DEFAULT_INTERVAL=2

# ============================================
# 함수: 현재 cron에서 Watchdog 간격 읽기
# ============================================
get_current_interval() {
    local cron_line=$(crontab -l 2>/dev/null | grep "podman_watchdog" | head -1)
    if [ -z "$cron_line" ]; then
        echo "미등록"
        return
    fi

    # */N 형식에서 N 추출
    local interval=$(echo "$cron_line" | grep -oP '^\*/\K[0-9]+')
    if [ -n "$interval" ]; then
        echo "${interval}"
    else
        # * * * * * 형식이면 1분
        echo "1"
    fi
}

# ============================================
# 함수: 인자에서 간격 파싱
# ============================================
parse_interval() {
    local interval=""
    # 모든 인자에서 --interval N 또는 숫자만 찾기
    while [ $# -gt 0 ]; do
        case "$1" in
            --interval|-i)
                shift
                interval="$1"
                ;;
            [0-9]|[0-9][0-9])
                interval="$1"
                ;;
        esac
        shift 2>/dev/null || break
    done
    echo "$interval"
}

# ============================================
# 함수: cron 항목 생성
# ============================================
make_cron_entries() {
    local interval=$1

    if [ "$interval" -eq 1 ]; then
        CRON_SCHEDULE="* * * * *"
    else
        CRON_SCHEDULE="*/${interval} * * * *"
    fi

    CRON_COMMENT_WATCHDOG="# ----- Podman 컨테이너 Watchdog (${interval}분 간격) -----"
    CRON_ENTRY_WATCHDOG="${CRON_SCHEDULE} ${WATCHDOG_SCRIPT}"
}

# ============================================
# 함수: 상태 확인
# ============================================
show_status() {
    echo ""
    echo -e "${BLUE}===== Watchdog 상태 확인 =====${NC}"
    echo ""

    # 1. 스크립트 파일 확인
    echo -e "${BLUE}[1] 스크립트 파일${NC}"
    for script in "$WATCHDOG_SCRIPT" "$METRICS_SCRIPT"; do
        if [ -f "$script" ]; then
            local perm=$(stat -c '%a' "$script")
            if [ "$perm" = "755" ] || [ "$perm" = "775" ] || [ "$perm" = "700" ]; then
                echo -e "  ${GREEN}OK${NC}  $script (권한: $perm)"
            else
                echo -e "  ${YELLOW}WARN${NC} $script (권한: $perm, 실행 권한 필요)"
            fi
        else
            echo -e "  ${RED}MISS${NC} $script (파일 없음)"
        fi
    done
    echo ""

    # 2. 디렉토리 확인
    echo -e "${BLUE}[2] 디렉토리${NC}"
    for dir in "$LOG_DIR" "$COOLDOWN_DIR" "$TEXTFILE_DIR"; do
        if [ -d "$dir" ]; then
            echo -e "  ${GREEN}OK${NC}  $dir"
        else
            echo -e "  ${RED}MISS${NC} $dir"
        fi
    done
    echo ""

    # 3. cron 등록 확인
    echo -e "${BLUE}[3] cron 등록${NC}"
    local cron_content=$(crontab -l 2>/dev/null || echo "")
    local current_interval=$(get_current_interval)

    if echo "$cron_content" | grep -q "podman_watchdog"; then
        echo -e "  ${GREEN}OK${NC}  Watchdog cron 등록됨 (${current_interval}분 간격)"
    else
        echo -e "  ${RED}MISS${NC} Watchdog cron 미등록"
    fi

    if echo "$cron_content" | grep -q "podman_metrics"; then
        echo -e "  ${GREEN}OK${NC}  Metrics cron 등록됨"
    else
        echo -e "  ${RED}MISS${NC} Metrics cron 미등록"
    fi

    if echo "$cron_content" | grep -q "alert_logger"; then
        echo -e "  ${GREEN}OK${NC}  Alert Logger cron 등록됨"
    else
        echo -e "  ${RED}MISS${NC} Alert Logger cron 미등록"
    fi
    echo ""

    # 4. 최근 로그
    echo -e "${BLUE}[4] 최근 Watchdog 로그 (최근 5줄)${NC}"
    if [ -f "${LOG_DIR}/watchdog.log" ]; then
        tail -5 "${LOG_DIR}/watchdog.log" | while read line; do
            echo "  $line"
        done
    else
        echo "  (로그 파일 없음)"
    fi
    echo ""

    # 4-2. 최근 알람 로그
    echo -e "${BLUE}[4-2] 최근 Alert 로그 (최근 5줄)${NC}"
    if [ -f "${LOG_DIR}/alert.log" ]; then
        tail -5 "${LOG_DIR}/alert.log" | while read line; do
            echo "  $line"
        done
    else
        echo "  (알람 로그 파일 없음)"
    fi
    echo ""

    # 5. 쿨다운 상태
    echo -e "${BLUE}[5] 쿨다운 상태${NC}"
    if [ -d "$COOLDOWN_DIR" ] && ls "$COOLDOWN_DIR"/*.cooldown &>/dev/null; then
        for f in "$COOLDOWN_DIR"/*.cooldown; do
            local name=$(basename "$f" .cooldown)
            local ts=$(cat "$f")
            local now=$(date +%s)
            local diff=$((now - ts))
            if [ $diff -lt 300 ]; then
                echo -e "  ${YELLOW}COOLDOWN${NC} $name (${diff}초 전 재시작, $((300-diff))초 남음)"
            else
                echo -e "  ${GREEN}READY${NC}    $name (쿨다운 만료)"
            fi
        done
    else
        echo "  (쿨다운 기록 없음)"
    fi
    echo ""

    # 6. suppress 상태
    echo -e "${BLUE}[6] Suppress 상태 (자동 재시작 방지)${NC}"
    if [ -d "$SUPPRESS_DIR" ] && ls "$SUPPRESS_DIR"/*.suppress &>/dev/null; then
        for f in "$SUPPRESS_DIR"/*.suppress; do
            local name=$(basename "$f" .suppress)
            local info=$(cat "$f")
            echo -e "  ${YELLOW}SUPPRESS${NC} $name ($info)"
        done
    else
        echo "  (suppress 설정 없음 - 모든 컨테이너 자동 재시작 가능)"
    fi
    echo ""

    # 7. 감시 대상 컨테이너
    echo -e "${BLUE}[7] 감시 대상 컨테이너${NC}"
    if [ -f "$CONF_FILE" ]; then
        local containers=$(grep -v '^\s*#' "$CONF_FILE" | grep -v '^\s*$' | tr -d ' ')
        if [ -n "$containers" ]; then
            echo "$containers" | while read c; do
                local state=$(podman inspect --format '{{.State.Status}}' "$c" 2>/dev/null || echo "not-found")
                local sup=""
                [ -f "${SUPPRESS_DIR}/${c}.suppress" ] && sup=" ${YELLOW}[SUPPRESS]${NC}"
                case "$state" in
                    running) echo -e "  ${GREEN}●${NC} $c ($state)$sup" ;;
                    exited|dead) echo -e "  ${RED}●${NC} $c ($state)$sup" ;;
                    *) echo -e "  ${YELLOW}○${NC} $c ($state)$sup" ;;
                esac
            done
        else
            echo "  (등록된 컨테이너 없음)"
        fi
    else
        echo "  (설정 파일 없음 - 기본값 사용)"
    fi
    echo ""
}

# ============================================
# 함수: 설치
# ============================================
install_watchdog() {
    local interval=${1:-$DEFAULT_INTERVAL}
    make_cron_entries "$interval"

    echo ""
    echo -e "${BLUE}===== Watchdog cron 등록 시작 (${interval}분 간격) =====${NC}"
    echo ""

    # 1. 디렉토리 생성
    echo -e "${BLUE}[1/4] 디렉토리 생성${NC}"
    for dir in "$LOG_DIR" "$COOLDOWN_DIR" "$SUPPRESS_DIR" "$ALERT_STATE_DIR" "$TEXTFILE_DIR"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            echo -e "  ${GREEN}생성${NC} $dir"
        else
            echo -e "  ${GREEN}존재${NC} $dir"
        fi
    done
    echo ""

    # 2. 스크립트 실행 권한 설정
    echo -e "${BLUE}[2/4] 스크립트 실행 권한 설정${NC}"
    # 필수 스크립트 (없으면 설치 중단)
    for script in "$WATCHDOG_SCRIPT" "$METRICS_SCRIPT"; do
        if [ -f "$script" ]; then
            chmod +x "$script"
            echo -e "  ${GREEN}OK${NC}  $script"
        else
            echo -e "  ${RED}ERROR${NC} $script (파일이 없습니다!)"
            echo -e "  ${RED}스크립트 파일을 먼저 생성하세요.${NC}"
            exit 1
        fi
    done
    # [2026-02-26] 선택 스크립트 (없으면 건너뜀)
    if [ -f "$ALERT_LOGGER_SCRIPT" ]; then
        chmod +x "$ALERT_LOGGER_SCRIPT"
        echo -e "  ${GREEN}OK${NC}  $ALERT_LOGGER_SCRIPT"
    else
        echo -e "  ${YELLOW}SKIP${NC} $ALERT_LOGGER_SCRIPT (파일 없음 - 알람 로그 기능 생략)"
    fi
    echo ""

    # 3. cron 등록 (중복 방지, 기존 watchdog 항목은 새 간격으로 교체)
    echo -e "${BLUE}[3/4] cron 등록${NC}"
    local cron_content=$(crontab -l 2>/dev/null || echo "")
    local cron_updated=false

    # Metrics cron 등록
    if echo "$cron_content" | grep -q "podman_metrics"; then
        echo -e "  ${GREEN}이미 등록됨${NC} Metrics cron"
    else
        cron_content="${cron_content}
# ----- Podman 컨테이너 메트릭 수집 (30초 간격) -----
* * * * * ${METRICS_SCRIPT}
* * * * * sleep 30 && ${METRICS_SCRIPT}"
        cron_updated=true
        echo -e "  ${GREEN}등록${NC} Metrics cron (30초 간격)"
    fi

    # [2026-02-26] Alert Logger cron 등록 (스크립트 파일이 있을 때만)
    if [ -f "$ALERT_LOGGER_SCRIPT" ]; then
        if echo "$cron_content" | grep -q "alert_logger"; then
            echo -e "  ${GREEN}이미 등록됨${NC} Alert Logger cron (변경 없음)"
        else
            cron_content="${cron_content}
# ----- [2026-02-26] 컨테이너 알람 로그 기록 (1분 간격) -----
* * * * * ${ALERT_LOGGER_SCRIPT}"
            cron_updated=true
            echo -e "  ${GREEN}등록${NC} Alert Logger cron (1분 간격)"
        fi
    fi

    # Watchdog cron 등록 (간격이 변경된 경우에만 교체)
    if echo "$cron_content" | grep -q "podman_watchdog"; then
        local old_interval=$(echo "$cron_content" | grep "podman_watchdog" | grep -oP '^\*/\K[0-9]+' || echo "1")
        if [ "$old_interval" = "$interval" ]; then
            echo -e "  ${GREEN}이미 등록됨${NC} Watchdog cron (${interval}분 간격, 변경 없음)"
        else
            # 간격 변경 시에만 기존 항목 제거 후 새 간격으로 등록
            cron_content=$(echo "$cron_content" | grep -v -E "(podman_watchdog|Podman.*Watchdog)")
            cron_content="${cron_content}
${CRON_COMMENT_WATCHDOG}
${CRON_ENTRY_WATCHDOG}"
            cron_updated=true
            echo -e "  ${GREEN}변경${NC} Watchdog cron (${old_interval}분 → ${interval}분)"
        fi
    else
        cron_content="${cron_content}
${CRON_COMMENT_WATCHDOG}
${CRON_ENTRY_WATCHDOG}"
        cron_updated=true
        echo -e "  ${GREEN}등록${NC} Watchdog cron (${interval}분 간격)"
    fi

    # cron 적용 (변경된 항목이 있을 때만)
    if [ "$cron_updated" = true ]; then
        echo "$cron_content" | crontab -
        echo ""
        echo -e "  ${GREEN}cron 적용 완료 (변경된 항목만 반영)${NC}"
    else
        echo ""
        echo -e "  ${GREEN}변경 사항 없음 (모든 cron이 이미 최신 상태)${NC}"
    fi
    echo ""

    # 4. 검증
    echo -e "${BLUE}[4/4] 등록 결과 검증${NC}"
    local final_cron=$(crontab -l 2>/dev/null)

    local check_ok=true
    if echo "$final_cron" | grep -q "podman_watchdog"; then
        local verified_interval=$(get_current_interval)
        echo -e "  ${GREEN}OK${NC}  Watchdog cron 확인됨 (${verified_interval}분 간격)"
    else
        echo -e "  ${RED}FAIL${NC} Watchdog cron 등록 실패"
        check_ok=false
    fi

    if echo "$final_cron" | grep -q "podman_metrics"; then
        echo -e "  ${GREEN}OK${NC}  Metrics cron 확인됨"
    else
        echo -e "  ${RED}FAIL${NC} Metrics cron 등록 실패"
        check_ok=false
    fi

    if echo "$final_cron" | grep -q "alert_logger"; then
        echo -e "  ${GREEN}OK${NC}  Alert Logger cron 확인됨"
    else
        echo -e "  ${RED}FAIL${NC} Alert Logger cron 등록 실패"
        check_ok=false
    fi

    echo ""
    if [ "$check_ok" = true ]; then
        echo -e "${GREEN}===== 설치 완료! =====${NC}"
        echo ""
        echo "등록된 cron 항목:"
        crontab -l | grep -E "(podman_watchdog|podman_metrics|alert_logger|Podman|컨테이너 알람)" | while read line; do
            echo "  $line"
        done
    else
        echo -e "${RED}===== 일부 항목 등록 실패 =====${NC}"
    fi
    echo ""
}

# ============================================
# 함수: 간격 변경
# ============================================
change_interval() {
    local new_interval=$1

    if [ -z "$new_interval" ]; then
        echo ""
        echo -e "${RED}간격(분)을 지정해주세요.${NC}"
        echo ""
        echo "사용법: $0 interval <분>"
        echo "  예: $0 interval 3    # 3분 간격으로 변경"
        echo ""
        exit 1
    fi

    # 숫자 검증
    if ! [[ "$new_interval" =~ ^[0-9]+$ ]] || [ "$new_interval" -lt 1 ] || [ "$new_interval" -gt 59 ]; then
        echo ""
        echo -e "${RED}간격은 1~59 사이의 숫자여야 합니다.${NC}"
        echo ""
        exit 1
    fi

    local current_interval=$(get_current_interval)

    if [ "$current_interval" = "미등록" ]; then
        echo ""
        echo -e "${YELLOW}Watchdog cron이 등록되어 있지 않습니다. install을 먼저 실행하세요.${NC}"
        echo ""
        exit 1
    fi

    if [ "$current_interval" = "$new_interval" ]; then
        echo ""
        echo -e "${GREEN}이미 ${new_interval}분 간격으로 설정되어 있습니다.${NC}"
        echo ""
        exit 0
    fi

    make_cron_entries "$new_interval"

    echo ""
    echo -e "${BLUE}===== Watchdog 간격 변경: ${current_interval}분 → ${new_interval}분 =====${NC}"
    echo ""

    # 기존 watchdog 항목 제거 후 새 간격으로 등록
    local cron_content=$(crontab -l 2>/dev/null || echo "")
    cron_content=$(echo "$cron_content" | grep -v -E "(podman_watchdog|Podman.*Watchdog)")
    cron_content="${cron_content}
${CRON_COMMENT_WATCHDOG}
${CRON_ENTRY_WATCHDOG}"

    echo "$cron_content" | crontab -

    # 검증
    local verified_interval=$(get_current_interval)
    if [ "$verified_interval" = "$new_interval" ]; then
        echo -e "  ${GREEN}OK${NC}  간격 변경 완료: ${verified_interval}분"
    else
        echo -e "  ${RED}FAIL${NC} 간격 변경 실패"
    fi

    echo ""
    echo "현재 Watchdog cron:"
    crontab -l | grep -E "(podman_watchdog|Podman.*Watchdog)" | while read line; do
        echo "  $line"
    done
    echo ""
}

# ============================================
# 함수: 감시 대상 컨테이너 목록 보기
# ============================================
list_containers() {
    echo ""
    echo -e "${BLUE}===== 감시 대상 컨테이너 목록 =====${NC}"
    echo ""

    if [ ! -f "$CONF_FILE" ]; then
        echo -e "  ${YELLOW}설정 파일 없음${NC} ($CONF_FILE)"
        echo -e "  기본값: sdc-open-webui sdc-redis-dev sdc-pipelines sdc-guardrails sdc-monitoring"
        echo ""
        return
    fi

    echo -e "  ${BLUE}설정 파일:${NC} $CONF_FILE"
    echo ""

    local idx=0
    while IFS= read -r line; do
        # 주석과 빈 줄 건너뛰기
        [[ "$line" =~ ^[[:space:]]*# ]] && continue
        [[ -z "$(echo "$line" | tr -d '[:space:]')" ]] && continue
        local container=$(echo "$line" | tr -d '[:space:]')
        idx=$((idx + 1))

        # suppress 상태 확인
        local suppress_status=""
        if [ -f "${SUPPRESS_DIR}/${container}.suppress" ]; then
            suppress_status=" ${YELLOW}[SUPPRESS]${NC}"
        fi

        # 컨테이너 실제 상태 확인
        local state=$(podman inspect --format '{{.State.Status}}' "$container" 2>/dev/null || echo "not-found")

        case "$state" in
            running)
                echo -e "  ${idx}. ${GREEN}●${NC} ${container} (${state})${suppress_status}"
                ;;
            exited|dead)
                echo -e "  ${idx}. ${RED}●${NC} ${container} (${state})${suppress_status}"
                ;;
            not-found)
                echo -e "  ${idx}. ${YELLOW}○${NC} ${container} (컨테이너 없음)${suppress_status}"
                ;;
            *)
                echo -e "  ${idx}. ${YELLOW}●${NC} ${container} (${state})${suppress_status}"
                ;;
        esac
    done < "$CONF_FILE"

    if [ "$idx" -eq 0 ]; then
        echo -e "  ${YELLOW}등록된 컨테이너가 없습니다.${NC}"
    fi
    echo ""
}

# ============================================
# 함수: 감시 대상 컨테이너 추가
# ============================================
add_container() {
    local container=$1

    if [ -z "$container" ]; then
        echo ""
        echo -e "${RED}컨테이너 이름을 지정해주세요.${NC}"
        echo "  사용법: $0 add <컨테이너명>"
        echo ""
        exit 1
    fi

    # 설정 파일 없으면 생성
    if [ ! -f "$CONF_FILE" ]; then
        cat > "$CONF_FILE" << 'CONF_EOF'
# ============================================================
# Podman Watchdog 설정 파일
# ============================================================
# 수정 후 별도 재시작 불필요 (다음 cron 실행 시 자동 반영)
#
# 감시 대상 컨테이너: 한 줄에 하나씩 작성
# '#'으로 시작하는 줄은 무시됨
# 빈 줄도 무시됨
# ============================================================

# ----- 감시 대상 컨테이너 목록 -----
CONF_EOF
    fi

    # 이미 등록되어 있는지 확인
    if grep -q "^${container}$" "$CONF_FILE" 2>/dev/null; then
        echo ""
        echo -e "${YELLOW}이미 등록된 컨테이너입니다: ${container}${NC}"
        echo ""
        return
    fi

    # 컨테이너 추가
    echo "$container" >> "$CONF_FILE"

    echo ""
    echo -e "${GREEN}컨테이너 추가 완료: ${container}${NC}"
    echo -e "  다음 Watchdog 실행 시 자동 반영됩니다."
    echo ""
}

# ============================================
# 함수: 감시 대상 컨테이너 제거
# ============================================
del_container() {
    local container=$1

    if [ -z "$container" ]; then
        echo ""
        echo -e "${RED}컨테이너 이름을 지정해주세요.${NC}"
        echo "  사용법: $0 del <컨테이너명>"
        echo ""
        exit 1
    fi

    if [ ! -f "$CONF_FILE" ]; then
        echo ""
        echo -e "${RED}설정 파일이 없습니다: ${CONF_FILE}${NC}"
        echo ""
        exit 1
    fi

    # 등록 여부 확인
    if ! grep -q "^${container}$" "$CONF_FILE" 2>/dev/null; then
        echo ""
        echo -e "${YELLOW}등록되지 않은 컨테이너입니다: ${container}${NC}"
        echo ""
        return
    fi

    # 컨테이너 제거 (해당 줄 삭제)
    local tmp_file="${CONF_FILE}.tmp"
    grep -v "^${container}$" "$CONF_FILE" > "$tmp_file"
    mv "$tmp_file" "$CONF_FILE"

    # suppress 파일도 제거
    rm -f "${SUPPRESS_DIR}/${container}.suppress"

    echo ""
    echo -e "${GREEN}컨테이너 제거 완료: ${container}${NC}"
    echo -e "  다음 Watchdog 실행 시 자동 반영됩니다."
    echo ""
}

# ============================================
# 함수: suppress (자동 재시작 방지)
# ============================================
suppress_container() {
    local container=$1

    if [ -z "$container" ]; then
        echo ""
        echo -e "${RED}컨테이너 이름을 지정해주세요.${NC}"
        echo "  사용법: $0 suppress <컨테이너명>"
        echo ""
        exit 1
    fi

    mkdir -p "$SUPPRESS_DIR"

    # 이미 suppress 중인지 확인
    if [ -f "${SUPPRESS_DIR}/${container}.suppress" ]; then
        echo ""
        echo -e "${YELLOW}이미 suppress 상태입니다: ${container}${NC}"
        echo ""
        return
    fi

    # suppress 파일 생성
    echo "$(date '+%Y-%m-%d %H:%M:%S') suppressed by user" > "${SUPPRESS_DIR}/${container}.suppress"

    echo ""
    echo -e "${GREEN}Suppress 설정 완료: ${container}${NC}"
    echo -e "  이 컨테이너는 exited/dead 상태여도 자동 재시작되지 않습니다."
    echo -e "  해제: $0 unsuppress ${container}"
    echo ""
}

# ============================================
# 함수: unsuppress (자동 재시작 방지 해제)
# ============================================
unsuppress_container() {
    local container=$1

    if [ -z "$container" ]; then
        echo ""
        echo -e "${RED}컨테이너 이름을 지정해주세요.${NC}"
        echo "  사용법: $0 unsuppress <컨테이너명>"
        echo ""
        exit 1
    fi

    # suppress 파일 확인
    if [ ! -f "${SUPPRESS_DIR}/${container}.suppress" ]; then
        echo ""
        echo -e "${YELLOW}suppress 상태가 아닙니다: ${container}${NC}"
        echo ""
        return
    fi

    # suppress 파일 제거
    rm -f "${SUPPRESS_DIR}/${container}.suppress"

    echo ""
    echo -e "${GREEN}Suppress 해제 완료: ${container}${NC}"
    echo -e "  이 컨테이너는 다시 자동 재시작 대상이 됩니다."
    echo ""
}

# ============================================
# 함수: 제거
# ============================================
remove_watchdog() {
    echo ""
    echo -e "${YELLOW}===== Watchdog cron 제거 =====${NC}"
    echo ""

    local cron_content=$(crontab -l 2>/dev/null || echo "")

    if ! echo "$cron_content" | grep -q "podman_watchdog\|podman_metrics\|alert_logger"; then
        echo -e "  ${YELLOW}등록된 Watchdog/Metrics/Alert cron이 없습니다.${NC}"
        echo ""
        return
    fi

    # watchdog, metrics, alert_logger 관련 항목 제거
    local new_cron=$(echo "$cron_content" | grep -v -E "(podman_watchdog|podman_metrics|alert_logger|Podman 컨테이너 메트릭|Podman.*Watchdog|컨테이너 알람 로그)")

    echo "$new_cron" | crontab -

    echo -e "  ${GREEN}cron 항목 제거 완료${NC}"
    echo ""
    echo "현재 cron 항목:"
    crontab -l 2>/dev/null | head -10
    echo ""

    echo -e "${YELLOW}참고: 로그 파일과 쿨다운 기록은 유지됩니다.${NC}"
    echo "  로그: ${LOG_DIR}/watchdog.log"
    echo "  쿨다운: ${COOLDOWN_DIR}/"
    echo ""
}

# ============================================
# 사용법 출력
# ============================================
show_usage() {
    local current_interval=$(get_current_interval)
    echo ""
    echo "사용법: $0 <명령> [옵션]"
    echo ""
    echo "--- cron 관리 ---"
    echo "  install [--interval N]     - Watchdog cron 등록 (기본: ${DEFAULT_INTERVAL}분)"
    echo "  interval <N>               - Watchdog 실행 간격 변경 (분 단위)"
    echo "  remove                     - Watchdog cron 제거"
    echo "  status                     - 현재 상태 확인"
    echo ""
    echo "--- 컨테이너 관리 ---"
    echo "  list                       - 감시 대상 컨테이너 목록 (상태 포함)"
    echo "  add <컨테이너명>            - 감시 대상 컨테이너 추가"
    echo "  del <컨테이너명>            - 감시 대상 컨테이너 제거"
    echo ""
    echo "--- suppress (자동 재시작 방지) ---"
    echo "  suppress <컨테이너명>       - 자동 재시작 방지 설정"
    echo "  unsuppress <컨테이너명>     - 자동 재시작 방지 해제"
    echo ""
    echo "현재 간격: ${current_interval}분"
    echo ""
    echo "예시:"
    echo "  $0 install                  # 기본(${DEFAULT_INTERVAL}분) 간격으로 설치"
    echo "  $0 install --interval 3     # 3분 간격으로 설치"
    echo "  $0 interval 5               # 간격을 5분으로 변경"
    echo "  $0 status                   # 전체 상태 확인"
    echo "  $0 list                     # 감시 대상 목록 + 상태"
    echo "  $0 add dify-api             # dify-api 감시 대상 추가"
    echo "  $0 del dify-api             # dify-api 감시 대상 제거"
    echo "  $0 suppress sdc-pipelines   # sdc-pipelines 자동 재시작 방지"
    echo "  $0 unsuppress sdc-pipelines # sdc-pipelines 자동 재시작 방지 해제"
    echo ""
}

# ============================================
# 메인 실행
# ============================================
COMMAND="${1:-install}"

case "$COMMAND" in
    install|setup)
        shift 2>/dev/null || true
        interval=$(parse_interval "$@")
        install_watchdog "${interval:-$DEFAULT_INTERVAL}"
        ;;
    interval|set-interval|change)
        change_interval "$2"
        ;;
    remove|uninstall)
        remove_watchdog
        ;;
    status|check)
        show_status
        ;;
    list|containers)
        list_containers
        ;;
    add|add-container)
        add_container "$2"
        ;;
    del|delete|remove-container|del-container)
        del_container "$2"
        ;;
    suppress|stop-watch)
        suppress_container "$2"
        ;;
    unsuppress|resume-watch)
        unsuppress_container "$2"
        ;;
    help|--help|-h)
        show_usage
        ;;
    *)
        echo -e "${RED}알 수 없는 명령: ${COMMAND}${NC}"
        show_usage
        exit 1
        ;;
esac
