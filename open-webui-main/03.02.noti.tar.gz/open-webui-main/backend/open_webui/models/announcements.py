# ----- [2026-02-04] 팝업 공지사항 관리 모델 시작 -----
# ----- [2026-02-04] 멀티모달(이미지) 지원 추가 -----
"""
팝업 공지사항 관리를 위한 데이터베이스 모델

기능:
- 공지사항 CRUD (생성, 조회, 수정, 삭제)
- 공지 기간 관리 (시작일시, 종료일시)
- 활성화된 공지사항 조회 (현재 날짜 기준)
- 이미지 첨부 지원 (멀티모달)

테이블: popup_announcements
"""

import logging
import time
import uuid
from typing import Optional, List

from pydantic import BaseModel, ConfigDict
from sqlalchemy import Column, String, Text, BigInteger, Boolean
from sqlalchemy.orm import Session

from open_webui.internal.db import Base, get_db

log = logging.getLogger(__name__)


####################
# DB Model
####################

class PopupAnnouncement(Base):
    """팝업 공지사항 테이블"""
    __tablename__ = "popup_announcements"

    id = Column(String, primary_key=True)
    title = Column(String(500), nullable=False)  # 공지 제목
    content = Column(Text, nullable=False)  # 공지 내용
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
    image_url = Column(Text, nullable=True)  # 이미지 URL (base64 또는 URL)
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
    author = Column(String(255), nullable=False)  # 작성자
    author_id = Column(String, nullable=False)  # 작성자 ID
    start_date = Column(BigInteger, nullable=False)  # 시작일시 (timestamp)
    end_date = Column(BigInteger, nullable=False)  # 종료일시 (timestamp)
    is_active = Column(Boolean, default=True)  # 활성화 여부
    created_at = Column(BigInteger, nullable=False)  # 생성일시
    updated_at = Column(BigInteger, nullable=False)  # 수정일시


####################
# Pydantic Models
####################

class PopupAnnouncementModel(BaseModel):
    """공지사항 응답 모델"""
    id: str
    title: str
    content: str
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
    image_url: Optional[str] = None  # 이미지 URL
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
    author: str
    author_id: str
    start_date: int
    end_date: int
    is_active: bool
    created_at: int
    updated_at: int

    model_config = ConfigDict(from_attributes=True)


class PopupAnnouncementForm(BaseModel):
    """공지사항 생성/수정 폼"""
    title: str
    content: str
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
    image_url: Optional[str] = None  # 이미지 URL (base64 또는 URL)
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
    start_date: int
    end_date: int


class PopupAnnouncementUpdateForm(BaseModel):
    """공지사항 수정 폼"""
    title: Optional[str] = None
    content: Optional[str] = None
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
    image_url: Optional[str] = None  # 이미지 URL (base64 또는 URL)
    # ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
    start_date: Optional[int] = None
    end_date: Optional[int] = None
    is_active: Optional[bool] = None


####################
# Functions
####################

class PopupAnnouncementsTable:
    """팝업 공지사항 테이블 관리 클래스"""

    def create_table(self) -> bool:
        """테이블 생성 (이미 존재하면 무시)"""
        try:
            with get_db() as db:
                # SQLAlchemy가 테이블을 자동으로 생성
                Base.metadata.create_all(bind=db.get_bind())
            log.info("[ANNOUNCEMENTS] Table created or already exists")
            return True
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to create table: {e}")
            return False

    def insert_announcement(
        self,
        title: str,
        content: str,
        author: str,
        author_id: str,
        start_date: int,
        end_date: int,
        # ----- [2026-02-04] 이미지 URL 파라미터 추가 (멀티모달) 시작 -----
        image_url: Optional[str] = None
        # ----- [2026-02-04] 이미지 URL 파라미터 추가 (멀티모달) 종료 -----
    ) -> Optional[PopupAnnouncementModel]:
        """새 공지사항 등록"""
        try:
            announcement_id = str(uuid.uuid4())
            current_time = int(time.time())

            with get_db() as db:
                new_announcement = PopupAnnouncement(
                    id=announcement_id,
                    title=title,
                    content=content,
                    # ----- [2026-02-04] 이미지 URL 저장 (멀티모달) 시작 -----
                    image_url=image_url,
                    # ----- [2026-02-04] 이미지 URL 저장 (멀티모달) 종료 -----
                    author=author,
                    author_id=author_id,
                    start_date=start_date,
                    end_date=end_date,
                    is_active=True,
                    created_at=current_time,
                    updated_at=current_time
                )
                db.add(new_announcement)
                db.commit()
                db.refresh(new_announcement)

                log.info(f"[ANNOUNCEMENTS] Created announcement: {announcement_id}")
                return PopupAnnouncementModel.model_validate(new_announcement)
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to insert announcement: {e}")
            return None

    def get_announcement_by_id(self, id: str) -> Optional[PopupAnnouncementModel]:
        """ID로 공지사항 조회"""
        try:
            with get_db() as db:
                announcement = db.query(PopupAnnouncement).filter(
                    PopupAnnouncement.id == id
                ).first()

                if announcement:
                    return PopupAnnouncementModel.model_validate(announcement)
                return None
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to get announcement: {e}")
            return None

    def get_all_announcements(self) -> List[PopupAnnouncementModel]:
        """모든 공지사항 조회 (최신순)"""
        try:
            with get_db() as db:
                announcements = db.query(PopupAnnouncement).order_by(
                    PopupAnnouncement.created_at.desc()
                ).all()

                return [
                    PopupAnnouncementModel.model_validate(a)
                    for a in announcements
                ]
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to get all announcements: {e}")
            return []

    # ----- [2026-03-02] get_active_announcements limit 파라미터 확인 시작 -----
    # ■ 확인: limit 파라미터 = MAX_POPUP_COUNT (configs.py에서 전달)
    # ■ 확인: is_active=True, 현재시간 범위 내, 최신순 limit개 반환
    # ■ 관리자/일반사용자 구분 없이 동일한 결과 반환 (정상)
    # ----- [2026-03-02] get_active_announcements limit 파라미터 확인 종료 -----
    def get_active_announcements(self, limit: int = 3) -> List[PopupAnnouncementModel]:
        """활성화된 공지사항 조회 (현재 시간 기준)

        Args:
            limit: 최대 표시 개수 (기본값: 3, 설정에서 변경 가능)
        """
        try:
            current_time = int(time.time())

            with get_db() as db:
                announcements = db.query(PopupAnnouncement).filter(
                    PopupAnnouncement.is_active == True,
                    PopupAnnouncement.start_date <= current_time,
                    PopupAnnouncement.end_date >= current_time
                ).order_by(
                    PopupAnnouncement.created_at.desc()
                ).limit(limit).all()

                return [
                    PopupAnnouncementModel.model_validate(a)
                    for a in announcements
                ]
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to get active announcements: {e}")
            return []

    def update_announcement(
        self,
        id: str,
        form: PopupAnnouncementUpdateForm
    ) -> Optional[PopupAnnouncementModel]:
        """공지사항 수정"""
        try:
            with get_db() as db:
                announcement = db.query(PopupAnnouncement).filter(
                    PopupAnnouncement.id == id
                ).first()

                if not announcement:
                    return None

                # 변경된 필드만 업데이트
                if form.title is not None:
                    announcement.title = form.title
                if form.content is not None:
                    announcement.content = form.content
                # ----- [2026-02-04] 이미지 URL 업데이트 (멀티모달) 시작 -----
                if form.image_url is not None:
                    announcement.image_url = form.image_url
                # ----- [2026-02-04] 이미지 URL 업데이트 (멀티모달) 종료 -----
                if form.start_date is not None:
                    announcement.start_date = form.start_date
                if form.end_date is not None:
                    announcement.end_date = form.end_date
                if form.is_active is not None:
                    announcement.is_active = form.is_active

                announcement.updated_at = int(time.time())

                db.commit()
                db.refresh(announcement)

                log.info(f"[ANNOUNCEMENTS] Updated announcement: {id}")
                return PopupAnnouncementModel.model_validate(announcement)
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to update announcement: {e}")
            return None

    def delete_announcement(self, id: str) -> bool:
        """공지사항 삭제"""
        try:
            with get_db() as db:
                result = db.query(PopupAnnouncement).filter(
                    PopupAnnouncement.id == id
                ).delete()
                db.commit()

                if result > 0:
                    log.info(f"[ANNOUNCEMENTS] Deleted announcement: {id}")
                    return True
                return False
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to delete announcement: {e}")
            return False

    def delete_announcements(self, ids: List[str]) -> int:
        """여러 공지사항 삭제"""
        try:
            with get_db() as db:
                result = db.query(PopupAnnouncement).filter(
                    PopupAnnouncement.id.in_(ids)
                ).delete(synchronize_session='fetch')
                db.commit()

                log.info(f"[ANNOUNCEMENTS] Deleted {result} announcements")
                return result
        except Exception as e:
            log.error(f"[ANNOUNCEMENTS] Failed to delete announcements: {e}")
            return 0


# 싱글톤 인스턴스
PopupAnnouncements = PopupAnnouncementsTable()

# ----- [2026-02-04] 팝업 공지사항 관리 모델 종료 -----
