// ----- [2026-02-04] 팝업 공지사항 관리 API 시작 -----
/**
 * 팝업 공지사항 관리 API 함수
 *
 * 기능:
 * - 공지사항 CRUD (생성, 조회, 수정, 삭제)
 * - 활성 공지사항 조회 (로그인 시 팝업 표시용)
 * - 다중 삭제 지원
 */

import { WEBUI_API_BASE_URL } from '$lib/constants';

// 공지사항 타입 정의
export interface PopupAnnouncement {
	id: string;
	title: string;
	content: string;
	// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
	image_url?: string;  // 이미지 URL (base64 또는 URL)
	// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
	author: string;
	author_id: string;
	start_date: number;
	end_date: number;
	is_active: boolean;
	created_at: number;
	updated_at: number;
}

// 공지사항 생성/수정 폼 타입
export interface AnnouncementForm {
	title: string;
	content: string;
	// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
	image_url?: string;  // 이미지 URL (base64 또는 URL)
	// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
	start_date: number;
	end_date: number;
}

// 공지사항 수정 폼 타입
export interface AnnouncementUpdateForm {
	title?: string;
	content?: string;
	// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
	image_url?: string;  // 이미지 URL (base64 또는 URL)
	// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
	start_date?: number;
	end_date?: number;
	is_active?: boolean;
}

/**
 * 모든 공지사항 조회 (관리자 전용)
 */
export const getAnnouncements = async (token: string): Promise<PopupAnnouncement[]> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements`, {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		}
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return [];
		});

	if (error) {
		throw error;
	}

	return res;
};

/**
 * 활성화된 공지사항 조회 (일반 사용자용, 최근 3개)
 */
// ----- [2026-03-02] getActiveAnnouncements 팝업 개수 적용 확인 시작 -----
// ■ 확인: GET /configs/announcements/active → 백엔드 get_verified_user → 모든 사용자 접근 가능
// ■ 백엔드에서 MAX_POPUP_COUNT 적용된 결과 반환 (limit=max_popup_count)
// ■ API 테스트: 관리자(200), 일반사용자(200) 동일 공지 목록 반환 확인 완료
// ----- [2026-03-02] getActiveAnnouncements 팝업 개수 적용 확인 종료 -----
export const getActiveAnnouncements = async (token: string): Promise<PopupAnnouncement[]> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements/active`, {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		}
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return [];
		});

	if (error) {
		throw error;
	}

	return res;
};

/**
 * 특정 공지사항 조회
 */
export const getAnnouncementById = async (
	token: string,
	id: string
): Promise<PopupAnnouncement | null> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements/${id}`, {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		}
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return null;
		});

	if (error) {
		throw error;
	}

	return res;
};

/**
 * 새 공지사항 등록 (관리자 전용)
 */
export const createAnnouncement = async (
	token: string,
	form: AnnouncementForm
): Promise<PopupAnnouncement | null> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		},
		body: JSON.stringify(form)
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return null;
		});

	if (error) {
		throw error;
	}

	return res;
};

/**
 * 공지사항 수정 (관리자 전용)
 */
export const updateAnnouncement = async (
	token: string,
	id: string,
	form: AnnouncementUpdateForm
): Promise<PopupAnnouncement | null> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements/${id}`, {
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		},
		body: JSON.stringify(form)
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return null;
		});

	if (error) {
		throw error;
	}

	return res;
};

/**
 * 공지사항 삭제 (관리자 전용)
 */
export const deleteAnnouncement = async (
	token: string,
	id: string
): Promise<{ status: boolean; message: string }> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements/${id}`, {
		method: 'DELETE',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		}
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return { status: false, message: '' };
		});

	if (error) {
		throw error;
	}

	return res;
};

/**
 * 여러 공지사항 삭제 (관리자 전용)
 */
export const bulkDeleteAnnouncements = async (
	token: string,
	ids: string[]
): Promise<{ status: boolean; message: string; deleted_count: number }> => {
	let error = null;

	const res = await fetch(`${WEBUI_API_BASE_URL}/configs/announcements/bulk-delete`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`
		},
		body: JSON.stringify({ ids })
	})
		.then(async (res) => {
			if (!res.ok) throw await res.json();
			return res.json();
		})
		.catch((err) => {
			console.error(err);
			error = err.detail;
			return { status: false, message: '', deleted_count: 0 };
		});

	if (error) {
		throw error;
	}

	return res;
};

// ----- [2026-02-04] 팝업 공지사항 관리 API 종료 -----
