<!-- ----- [2026-02-04] 팝업 공지사항 관리 컴포넌트 시작 ----- -->
<!--
  팝업 공지사항 관리 컴포넌트

  기능:
  - 공지사항 CRUD (등록, 수정, 삭제, 조회)
  - 다중 선택 및 일괄 삭제
  - 시작/종료일시 설정
  - [2026-02-05] RichTextInput 에디터 (이미지, 표 지원)
  - [2026-02-05] 팝업 개수 설정
  - [2026-02-05] 활성/비활성 클릭 토글
-->
<script lang="ts">
	import { onMount, getContext } from 'svelte';
	import { toast } from 'svelte-sonner';
	// ----- [2026-02-05] RichTextInput 에디터 추가 시작 -----
	import RichTextInput from '$lib/components/common/RichTextInput.svelte';
	// ----- [2026-02-05] RichTextInput 에디터 추가 종료 -----
	import {
		getAnnouncements,
		createAnnouncement,
		updateAnnouncement,
		deleteAnnouncement,
		bulkDeleteAnnouncements,
		type PopupAnnouncement,
		type AnnouncementForm
	} from '$lib/apis/announcements';
	// ----- [2026-02-05] 팝업 개수 설정 저장을 위한 config API 추가 시작 -----
	import { exportConfig, updateConfigPartial } from '$lib/apis/configs';
	// ----- [2026-02-05] 팝업 개수 설정 저장을 위한 config API 추가 종료 -----

	const i18n = getContext('i18n');

	// 공지사항 관리 상태 변수
	let announcements: PopupAnnouncement[] = [];
	let selectedAnnouncements: Set<string> = new Set();
	let showAnnouncementForm = false;
	let editingAnnouncement: PopupAnnouncement | null = null;
	let announcementForm: AnnouncementForm = {
		title: '',
		content: '',
		// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 시작 -----
		image_url: '',
		// ----- [2026-02-04] 이미지 URL 필드 추가 (멀티모달) 종료 -----
		start_date: Math.floor(Date.now() / 1000),
		end_date: Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60 // 기본 7일 후
	};

	// ----- [2026-02-05] 미리보기 기능 변수 시작 -----
	let showPreview = false;
	// ----- [2026-02-05] 미리보기 기능 변수 종료 -----

	// ----- [2026-02-05] 팝업 개수 설정 변수 시작 -----
	// ----- [2026-02-26] MAX_POPUP_COUNT 팝업 표시 개수 설정 상세 설명 시작 -----
	// ■ 기능: 로그인 시 사용자에게 표시할 팝업 공지사항 최대 개수를 관리자가 설정
	//
	// ■ 데이터 흐름 (저장):
	//   1. 관리자가 이 화면(/admin/settings/notification)에서 개수 입력 (1~10)
	//   2. handlePopupCountChange() → 1초 디바운스 후 savePopupCount() 자동 호출
	//   3. savePopupCount() → updateConfigPartial(token, { MAX_POPUP_COUNT: N })
	//   4. updateConfigPartial() → exportConfig()로 현재 전체 설정 조회 → MAX_POPUP_COUNT 병합
	//   5. importConfig() → POST /api/v1/configs/import → PostgreSQL config 테이블 data(JSONB) 컬럼에 저장
	//
	// ■ 데이터 흐름 (적용 - 로그인 시 팝업):
	//   1. +layout.svelte onMount → loadPopupAnnouncements()
	//   2. getActiveAnnouncements(token) → GET /api/v1/configs/announcements/active
	//   3. 백엔드 configs.py get_active_announcements():
	//      - get_config()에서 MAX_POPUP_COUNT 읽기 (기본값 3)
	//      - PopupAnnouncements.get_active_announcements(limit=max_popup_count)
	//      - 활성 공지 중 최근 N개만 반환
	//   4. +layout.svelte에서 받은 공지를 PopupAnnouncementModal에 전달하여 팝업 표시
	//
	// ■ 데이터 흐름 (적용 - Navbar 공지 다시보기):
	//   1. Navbar.svelte 메가폰 아이콘 클릭 → loadAndShowAnnouncements()
	//   2. getActiveAnnouncements(token) → 백엔드에서 MAX_POPUP_COUNT 적용된 결과 반환
	//   3. PopupAnnouncementModal에 전달하여 팝업 표시
	//
	// ■ DB 저장 위치: PostgreSQL config 테이블 → data 컬럼(JSONB) → MAX_POPUP_COUNT 키
	// ■ 기본값: 3개 (백엔드 configs.py와 프론트엔드 모두 동일)
	// ■ 허용 범위: 1~10개 (UI input min/max 제한)
	// ----- [2026-02-26] MAX_POPUP_COUNT 팝업 표시 개수 설정 상세 설명 종료 -----
	let maxPopupCount = 3;
	let isSavingPopupCount = false;
	let popupCountLoaded = false; // 로드 완료 플래그 (자동 저장 방지)
	// ----- [2026-02-05] 팝업 개수 설정 변수 종료 -----

	// ----- [2026-03-02] MAX_POPUP_COUNT 설정 로드/저장 확인 시작 -----
	// ■ 확인: loadPopupSettings → exportConfig(token) → GET /configs/export (get_verified_user)
	// ■ 확인: savePopupCount → updateConfigPartial → exportConfig + importConfig (get_admin_user)
	// ■ 결과: 로드는 모든 사용자 가능, 저장은 관리자만 가능 (정상 동작)
	// ----- [2026-03-02] MAX_POPUP_COUNT 설정 로드/저장 확인 종료 -----
	// ----- [2026-02-05] 팝업 개수 설정 로드/저장 함수 시작 -----
	// [2026-02-26] loadPopupSettings: 페이지 로드 시 exportConfig()로 현재 MAX_POPUP_COUNT 값을 조회
	//   - GET /api/v1/configs/export → config 테이블 data(JSONB) 전체 반환
	//   - config.MAX_POPUP_COUNT 값이 있으면 maxPopupCount 변수에 반영
	//   - 실패 시 기본값 3 유지
	const loadPopupSettings = async () => {
		try {
			const config = await exportConfig(localStorage.token);
			if (config && config.MAX_POPUP_COUNT !== undefined) {
				maxPopupCount = config.MAX_POPUP_COUNT;
				console.log('[Notification] 팝업 개수 설정 로드됨:', maxPopupCount);
			}
		} catch (error) {
			console.log('팝업 설정 로드 (기본값 사용):', error);
			// 기본값 유지
		}
		popupCountLoaded = true;
	};

	// [2026-02-26] savePopupCount: MAX_POPUP_COUNT를 config 테이블에 저장
	//   - updateConfigPartial() 호출 → 기존 config에 { MAX_POPUP_COUNT: N } 병합 후 저장
	//   - POST /api/v1/configs/import → config 테이블 data(JSONB) UPDATE
	//   - 저장 후 다음 로그인 또는 공지 다시보기 시 백엔드에서 새 값 적용
	const savePopupCount = async () => {
		if (isSavingPopupCount) return;
		isSavingPopupCount = true;
		console.log('[Notification] 팝업 개수 저장 시작:', maxPopupCount);
		try {
			await updateConfigPartial(localStorage.token, {
				MAX_POPUP_COUNT: maxPopupCount
			});
			console.log('[Notification] 팝업 개수 저장 성공!');
			toast.success(`팝업 표시 개수가 ${maxPopupCount}개로 저장되었습니다`);
		} catch (error) {
			console.error('[Notification] 팝업 개수 저장 실패:', error);
			toast.error('팝업 표시 개수 저장에 실패했습니다');
		} finally {
			isSavingPopupCount = false;
		}
	};

	// [2026-02-26] handlePopupCountChange: 값 변경 시 1초 디바운스 후 자동 저장
	//   - 초기 로드 시에는 popupCountLoaded=false이므로 자동 저장하지 않음
	//   - 사용자가 input 값을 변경하면 1초 후 savePopupCount() 호출
	let saveTimeout: ReturnType<typeof setTimeout>;
	const handlePopupCountChange = () => {
		if (!popupCountLoaded) return; // 초기 로드 시에는 저장하지 않음
		clearTimeout(saveTimeout);
		saveTimeout = setTimeout(() => {
			savePopupCount();
		}, 1000); // 1초 후 자동 저장
	};
	// ----- [2026-02-05] 팝업 개수 설정 로드/저장 함수 종료 -----

	// 공지사항 목록 로드
	const loadAnnouncements = async () => {
		try {
			announcements = await getAnnouncements(localStorage.token);
		} catch (error) {
			console.error('공지사항 목록 로드 실패:', error);
			toast.error('공지사항 목록을 불러오는데 실패했습니다');
		}
	};

	// 공지사항 선택 토글
	const toggleAnnouncementSelection = (id: string) => {
		if (selectedAnnouncements.has(id)) {
			selectedAnnouncements.delete(id);
		} else {
			selectedAnnouncements.add(id);
		}
		selectedAnnouncements = new Set(selectedAnnouncements);
	};

	// 전체 선택/해제
	const toggleSelectAll = () => {
		if (selectedAnnouncements.size === announcements.length) {
			selectedAnnouncements.clear();
		} else {
			selectedAnnouncements = new Set(announcements.map((a) => a.id));
		}
		selectedAnnouncements = new Set(selectedAnnouncements);
	};

	// 공지사항 등록 폼 열기
	const openAnnouncementForm = () => {
		editingAnnouncement = null;
		announcementForm = {
			title: '',
			content: '',
			start_date: Math.floor(Date.now() / 1000),
			end_date: Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60
		};
		showAnnouncementForm = true;
	};

	// 공지사항 수정 폼 열기
	const openEditForm = (announcement: PopupAnnouncement) => {
		editingAnnouncement = announcement;
		announcementForm = {
			title: announcement.title,
			content: announcement.content,
			start_date: announcement.start_date,
			end_date: announcement.end_date
		};
		showAnnouncementForm = true;
	};

	// 공지사항 폼 닫기
	const closeAnnouncementForm = () => {
		showAnnouncementForm = false;
		editingAnnouncement = null;
	};

	// 공지사항 저장 (등록/수정)
	const saveAnnouncement = async () => {
		if (!announcementForm.title.trim()) {
			toast.error('공지 제목을 입력해주세요');
			return;
		}
		if (!announcementForm.content.trim()) {
			toast.error('공지 내용을 입력해주세요');
			return;
		}
		if (announcementForm.start_date >= announcementForm.end_date) {
			toast.error('종료일시는 시작일시보다 이후여야 합니다');
			return;
		}

		try {
			if (editingAnnouncement) {
				// 수정
				await updateAnnouncement(localStorage.token, editingAnnouncement.id, announcementForm);
				toast.success('공지사항이 수정되었습니다');
			} else {
				// 등록
				await createAnnouncement(localStorage.token, announcementForm);
				toast.success('공지사항이 등록되었습니다');
			}
			closeAnnouncementForm();
			await loadAnnouncements();
		} catch (error) {
			console.error('공지사항 저장 실패:', error);
			toast.error(`공지사항 저장에 실패했습니다: ${error}`);
		}
	};

	// 공지사항 삭제
	const handleDeleteAnnouncement = async (id: string) => {
		if (!confirm('이 공지사항을 삭제하시겠습니까?')) return;

		try {
			await deleteAnnouncement(localStorage.token, id);
			toast.success('공지사항이 삭제되었습니다');
			selectedAnnouncements.delete(id);
			selectedAnnouncements = new Set(selectedAnnouncements);
			await loadAnnouncements();
		} catch (error) {
			console.error('공지사항 삭제 실패:', error);
			toast.error(`공지사항 삭제에 실패했습니다: ${error}`);
		}
	};

	// 선택된 공지사항 일괄 삭제
	const handleBulkDelete = async () => {
		if (selectedAnnouncements.size === 0) return;
		if (!confirm(`${selectedAnnouncements.size}개의 공지사항을 삭제하시겠습니까?`)) return;

		try {
			const result = await bulkDeleteAnnouncements(
				localStorage.token,
				Array.from(selectedAnnouncements)
			);
			toast.success(result.message);
			selectedAnnouncements.clear();
			selectedAnnouncements = new Set(selectedAnnouncements);
			await loadAnnouncements();
		} catch (error) {
			console.error('공지사항 일괄 삭제 실패:', error);
			toast.error(`공지사항 삭제에 실패했습니다: ${error}`);
		}
	};

	// timestamp를 datetime-local 형식으로 변환 (한국 시간)
	const timestampToDatetimeLocal = (timestamp: number): string => {
		const date = new Date(timestamp * 1000);
		// 로컬 시간으로 변환 (YYYY-MM-DDTHH:mm 형식)
		const year = date.getFullYear();
		const month = String(date.getMonth() + 1).padStart(2, '0');
		const day = String(date.getDate()).padStart(2, '0');
		const hours = String(date.getHours()).padStart(2, '0');
		const minutes = String(date.getMinutes()).padStart(2, '0');
		return `${year}-${month}-${day}T${hours}:${minutes}`;
	};

	// datetime-local 형식을 timestamp로 변환
	const datetimeLocalToTimestamp = (datetime: string): number => {
		return Math.floor(new Date(datetime).getTime() / 1000);
	};

	// 날짜 포맷팅 (표시용) - 한국 시간
	const formatDate = (timestamp: number): string => {
		const date = new Date(timestamp * 1000);
		const year = date.getFullYear();
		const month = String(date.getMonth() + 1).padStart(2, '0');
		const day = String(date.getDate()).padStart(2, '0');
		const hours = String(date.getHours()).padStart(2, '0');
		const minutes = String(date.getMinutes()).padStart(2, '0');
		return `${year}.${month}.${day} ${hours}:${minutes}`;
	};

	// ----- [2026-02-05] 미리보기 관련 함수 시작 -----
	// 날짜 포맷팅 (미리보기용) - 한국어 형식
	const formatDateForPreview = (timestamp: number): string => {
		const date = new Date(timestamp * 1000);
		return date.toLocaleDateString('ko-KR', {
			year: 'numeric',
			month: 'long',
			day: 'numeric'
		});
	};

	// HTML 콘텐츠를 안전하게 렌더링 (RichTextInput 출력용)
	const renderContentWithImages = (content: string): string => {
		if (!content) return '';
		// RichTextInput은 이미 HTML을 출력하므로 그대로 사용
		// 단, 기본적인 XSS 위험 태그만 제거
		return content
			.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
			.replace(/on\w+="[^"]*"/gi, '');
	};

	// 미리보기 열기
	const openPreview = () => {
		if (!announcementForm.title.trim()) {
			toast.error('미리보기를 하려면 제목을 입력해주세요');
			return;
		}
		if (!announcementForm.content.trim()) {
			toast.error('미리보기를 하려면 내용을 입력해주세요');
			return;
		}
		showPreview = true;
	};

	// 미리보기 닫기
	const closePreview = () => {
		showPreview = false;
	};
	// ----- [2026-02-05] 미리보기 관련 함수 종료 -----

	// ----- [2026-02-05] 활성/비활성 토글 함수 시작 -----
	const toggleAnnouncementActive = async (announcement: PopupAnnouncement) => {
		try {
			await updateAnnouncement(localStorage.token, announcement.id, {
				...announcement,
				is_active: !announcement.is_active
			});
			toast.success(announcement.is_active ? '공지사항이 비활성화되었습니다' : '공지사항이 활성화되었습니다');
			await loadAnnouncements();
		} catch (error) {
			console.error('상태 변경 실패:', error);
			toast.error('상태 변경에 실패했습니다');
		}
	};
	// ----- [2026-02-05] 활성/비활성 토글 함수 종료 -----

	onMount(async () => {
		await loadAnnouncements();
		// ----- [2026-02-05] 팝업 개수 설정 로드 -----
		await loadPopupSettings();
	});
</script>

<div class="flex flex-col h-full justify-between space-y-3 text-sm">
	<div class="mt-0.5 space-y-3 overflow-y-scroll scrollbar-hidden h-full">
		<div class="">
			<div class="mb-3.5">
				<div class="mb-2.5 text-base font-medium">팝업 공지사항 관리</div>

				<hr class="border-gray-100 dark:border-gray-850 my-2" />

				<div class="text-xs text-gray-500 mb-4">
					로그인 시 사용자에게 표시될 팝업 공지사항을 관리합니다. 활성화된 공지사항 중 최근 {maxPopupCount}개가 표시됩니다.
				</div>

				<!-- ----- [2026-02-05] 팝업 표시 개수 설정 시작 ----- -->
			<!-- [2026-02-26] 관리자가 MAX_POPUP_COUNT 값을 설정하는 UI 영역
			     - input(1~10) 값 변경 → handlePopupCountChange() → 1초 디바운스 후 자동 저장
			     - 저장 버튼 클릭 → savePopupCount() → updateConfigPartial()
			     - 저장 경로: POST /api/v1/configs/import → config 테이블 data(JSONB) → MAX_POPUP_COUNT 키
			     - 적용 시점: 다음 로그인 시 또는 Navbar 공지 다시보기 버튼 클릭 시 백엔드에서 새 값 적용 -->
				<div class="mb-4 p-3 bg-gray-50 dark:bg-gray-850 rounded-lg">
					<div class="flex items-center justify-between">
						<label class="text-xs font-medium text-gray-700 dark:text-gray-300">팝업 표시 개수</label>
						<div class="flex items-center space-x-2">
							<input
								type="number"
								min="1"
								max="10"
								class="w-16 rounded-lg py-1.5 px-2 text-sm text-center bg-white dark:bg-gray-900 dark:text-gray-300 outline-none border border-gray-200 dark:border-gray-700"
								bind:value={maxPopupCount}
								on:input={handlePopupCountChange}
							/>
							<span class="text-xs text-gray-500">개</span>
							<button
								type="button"
								class="px-3 py-1.5 text-xs font-medium bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-1"
								on:click={savePopupCount}
								disabled={isSavingPopupCount}
							>
								{#if isSavingPopupCount}
									<svg class="animate-spin h-3 w-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
										<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
										<path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
									</svg>
									<span>저장 중...</span>
								{:else}
									<span>저장</span>
								{/if}
							</button>
						</div>
					</div>
					<div class="text-xs text-gray-400 mt-1">
						활성화된 공지사항 중 최근 n개가 로그인 시 팝업으로 표시됩니다. (1~10개)
					</div>
				</div>
				<!-- ----- [2026-02-05] 팝업 표시 개수 설정 종료 ----- -->

				<!-- 공지사항 등록/수정 폼 -->
				{#if showAnnouncementForm}
					<div class="mb-4 p-4 bg-gray-50 dark:bg-gray-850 rounded-lg">
						<div class="mb-3 text-sm font-medium">
							{editingAnnouncement ? '공지사항 수정' : '새 공지사항 등록'}
						</div>

						<div class="space-y-3">
							<div>
								<label class="block text-xs font-medium mb-1">공지 제목 *</label>
								<input
									type="text"
									class="w-full rounded-lg py-2 px-3 text-sm bg-white dark:bg-gray-900 dark:text-gray-300 outline-none border border-gray-200 dark:border-gray-700"
									placeholder="공지 제목을 입력하세요"
									bind:value={announcementForm.title}
								/>
							</div>

							<!-- ----- [2026-02-05] RichTextInput 에디터 (이미지, 표 지원) 시작 ----- -->
							<div>
								<label class="block text-xs font-medium mb-1">공지 내용 * (이미지 드래그&드롭/붙여넣기, 표 지원)</label>
								<div class="w-full rounded-lg bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 min-h-[200px] overflow-hidden">
									<RichTextInput
										bind:value={announcementForm.content}
										placeholder="공지 내용을 입력하세요. 텍스트 선택 시 서식 도구가 표시됩니다."
										className="prose prose-sm dark:prose-invert max-w-none min-h-[180px] p-3"
										richText={true}
										image={true}
										fileHandler={true}
										raw={true}
									/>
								</div>
								<div class="text-xs text-gray-400 mt-1">
									* 텍스트 선택 시 굵게, 기울임, 표 등 서식 도구가 표시됩니다. 이미지는 드래그&드롭 또는 Ctrl+V로 붙여넣기 가능합니다.
								</div>
							</div>
							<!-- ----- [2026-02-05] RichTextInput 에디터 (이미지, 표 지원) 종료 ----- -->

							<div class="grid grid-cols-2 gap-3">
								<div>
									<label class="block text-xs font-medium mb-1">시작일시 *</label>
									<input
										type="datetime-local"
										class="w-full rounded-lg py-2 px-3 text-sm bg-white dark:bg-gray-900 dark:text-gray-300 outline-none border border-gray-200 dark:border-gray-700"
										value={timestampToDatetimeLocal(announcementForm.start_date)}
										on:change={(e) => {
											announcementForm.start_date = datetimeLocalToTimestamp(e.currentTarget.value);
										}}
									/>
								</div>
								<div>
									<label class="block text-xs font-medium mb-1">종료일시 *</label>
									<input
										type="datetime-local"
										class="w-full rounded-lg py-2 px-3 text-sm bg-white dark:bg-gray-900 dark:text-gray-300 outline-none border border-gray-200 dark:border-gray-700"
										value={timestampToDatetimeLocal(announcementForm.end_date)}
										on:change={(e) => {
											announcementForm.end_date = datetimeLocalToTimestamp(e.currentTarget.value);
										}}
									/>
								</div>
							</div>

							<div class="flex justify-end space-x-2 pt-2">
								<button
									type="button"
									class="px-3 py-1.5 text-sm font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition"
									on:click={closeAnnouncementForm}
								>
									취소
								</button>
								<!-- ----- [2026-02-05] 미리보기 버튼 추가 시작 ----- -->
								<button
									type="button"
									class="px-3 py-1.5 text-sm font-medium bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition flex items-center space-x-1"
									on:click={openPreview}
									title="저장 전 공지사항이 어떻게 보이는지 확인합니다"
								>
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
										<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
										<path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
									</svg>
									<span>미리보기</span>
								</button>
								<!-- ----- [2026-02-05] 미리보기 버튼 추가 종료 ----- -->
								<button
									type="button"
									class="px-3 py-1.5 text-sm font-medium bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition"
									on:click={saveAnnouncement}
								>
									{editingAnnouncement ? '수정' : '등록'}
								</button>
							</div>
						</div>
					</div>
				{/if}

				<!-- 공지사항 목록 -->
				<div class="mb-3">
					<div class="flex justify-between items-center mb-2">
						<div class="text-xs text-gray-500">
							총 {announcements.length}개의 공지사항
						</div>
						<div class="flex space-x-2">
							{#if selectedAnnouncements.size > 0}
								<button
									type="button"
									class="px-3 py-1.5 text-xs font-medium bg-red-500 hover:bg-red-600 text-white rounded-lg transition"
									on:click={handleBulkDelete}
								>
									선택 삭제 ({selectedAnnouncements.size})
								</button>
							{/if}
							<button
								type="button"
								class="px-3 py-1.5 text-xs font-medium bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition"
								on:click={openAnnouncementForm}
							>
								+ 새 공지 등록
							</button>
						</div>
					</div>

					{#if announcements.length > 0}
						<div class="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
							<!-- 테이블 헤더 -->
							<div class="flex items-center bg-gray-100 dark:bg-gray-800 text-xs font-medium text-gray-600 dark:text-gray-400">
								<div class="w-10 p-2 flex justify-center">
									<input
										type="checkbox"
										class="rounded"
										checked={selectedAnnouncements.size === announcements.length && announcements.length > 0}
										on:change={toggleSelectAll}
									/>
								</div>
								<div class="flex-1 p-2">제목</div>
								<div class="w-24 p-2 text-center">작성자</div>
								<div class="w-44 p-2 text-center">기간</div>
								<div class="w-20 p-2 text-center">상태</div>
								<div class="w-24 p-2 text-center">작업</div>
							</div>

							<!-- 테이블 내용 -->
							{#each announcements as announcement}
								{@const isActive = announcement.is_active &&
									announcement.start_date <= Math.floor(Date.now() / 1000) &&
									announcement.end_date >= Math.floor(Date.now() / 1000)}
								<div class="flex items-center border-t border-gray-200 dark:border-gray-700 text-sm hover:bg-gray-50 dark:hover:bg-gray-850">
									<div class="w-10 p-2 flex justify-center">
										<input
											type="checkbox"
											class="rounded"
											checked={selectedAnnouncements.has(announcement.id)}
											on:change={() => toggleAnnouncementSelection(announcement.id)}
										/>
									</div>
									<div class="flex-1 p-2">
										<div class="font-medium text-gray-900 dark:text-gray-100 truncate">
											{announcement.title}
										</div>
										<div class="text-xs text-gray-500 truncate mt-0.5">
											{announcement.content.replace(/<[^>]*>/g, '').slice(0, 50)}{announcement.content.length > 50 ? '...' : ''}
										</div>
									</div>
									<div class="w-24 p-2 text-center text-xs text-gray-600 dark:text-gray-400">
										{announcement.author}
									</div>
									<div class="w-44 p-2 text-center text-xs text-gray-600 dark:text-gray-400">
										<div>{formatDate(announcement.start_date)}</div>
										<div>~ {formatDate(announcement.end_date)}</div>
									</div>
									<!-- ----- [2026-02-05] 클릭으로 활성/비활성 토글 시작 ----- -->
									<div class="w-20 p-2 text-center">
										<button
											type="button"
											class="px-2 py-0.5 text-xs rounded-full cursor-pointer transition-all hover:scale-105 {isActive ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'}"
											on:click={() => toggleAnnouncementActive(announcement)}
											title="클릭하여 상태 변경"
										>
											{isActive ? '활성' : '비활성'}
										</button>
									</div>
									<!-- ----- [2026-02-05] 클릭으로 활성/비활성 토글 종료 ----- -->
									<div class="w-24 p-2 flex justify-center space-x-1">
										<button
											type="button"
											class="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded transition"
											on:click={() => openEditForm(announcement)}
										>
											수정
										</button>
										<button
											type="button"
											class="px-2 py-1 text-xs bg-red-100 hover:bg-red-200 text-red-600 dark:bg-red-900 dark:hover:bg-red-800 dark:text-red-300 rounded transition"
											on:click={() => handleDeleteAnnouncement(announcement.id)}
										>
											삭제
										</button>
									</div>
								</div>
							{/each}
						</div>
					{:else}
						<div class="text-center py-8 text-gray-400 dark:text-gray-500 text-sm">
							등록된 공지사항이 없습니다
						</div>
					{/if}
				</div>

				<div class="text-xs text-gray-400 mt-2">
					* 활성화된 공지사항 중 최근 {maxPopupCount}개가 로그인 시 팝업으로 표시됩니다. 상태를 클릭하면 활성/비활성을 변경할 수 있습니다.
				</div>
			</div>
		</div>
	</div>
</div>
<!-- ----- [2026-02-05] 미리보기 팝업 모달 시작 ----- -->
{#if showPreview}
	<!-- svelte-ignore a11y-click-events-have-key-events -->
	<!-- svelte-ignore a11y-no-static-element-interactions -->
	<div
		class="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm"
		style="z-index: 99999 !important;"
		on:click|self={closePreview}
	>
		<div class="relative w-full max-w-lg mx-4 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl overflow-hidden">
			<!-- 미리보기 배지 -->
			<div class="absolute top-2 right-12 z-10">
				<span class="px-2 py-1 text-xs font-bold bg-yellow-400 text-yellow-900 rounded-full shadow">
					미리보기
				</span>
			</div>

			<!-- 헤더 -->
			<div class="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-500 to-blue-600">
				<div class="flex items-center space-x-2">
					<svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
					</svg>
					<span class="text-lg font-semibold text-white">공지사항</span>
				</div>
				<button
					class="text-white/80 hover:text-white transition p-1"
					on:click={closePreview}
				>
					<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
					</svg>
				</button>
			</div>

			<!-- 공지 컨텐츠 -->
			<div class="p-5">
				<!-- 제목 -->
				<h3 class="text-xl font-bold text-gray-900 dark:text-white mb-3">
					{announcementForm.title || '(제목 없음)'}
				</h3>

				<!-- 작성 정보 -->
				<div class="flex items-center space-x-3 text-sm text-gray-500 dark:text-gray-400 mb-4">
					<span class="flex items-center">
						<svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
						</svg>
						관리자
					</span>
					<span>|</span>
					<span class="flex items-center">
						<svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
						</svg>
						{formatDateForPreview(announcementForm.start_date)} ~ {formatDateForPreview(announcementForm.end_date)}
					</span>
				</div>

				<!-- 내용 (RichText HTML 렌더링) -->
				<div class="prose prose-sm dark:prose-invert max-w-none text-gray-700 dark:text-gray-300 leading-relaxed max-h-60 overflow-y-auto">
					{@html renderContentWithImages(announcementForm.content)}
				</div>
			</div>

			<!-- 푸터 -->
			<div class="flex items-center justify-between px-5 py-3 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
				<button
					class="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition flex items-center"
					on:click={closePreview}
				>
					<svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
					</svg>
					오늘 하루 보지 않기
				</button>
				<div class="text-sm text-gray-500 dark:text-gray-400 font-medium">
					1 / 1
				</div>
			</div>
		</div>
	</div>
{/if}
<!-- ----- [2026-02-05] 미리보기 팝업 모달 종료 ----- -->

<!-- ----- [2026-02-04] 팝업 공지사항 관리 컴포넌트 종료 ----- -->
