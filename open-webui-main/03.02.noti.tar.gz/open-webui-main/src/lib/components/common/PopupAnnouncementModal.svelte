<!-- ----- [2026-02-04] 팝업 공지 컴포넌트 시작 ----- -->
<!--
  팝업 공지 컴포넌트

  기능:
  - 로그인 시 활성화된 공지사항 표시
  - 최대 3개의 공지사항 표시
  - 수동 네비게이션 (이전/다음 버튼, 인디케이터 클릭)
  - "오늘 하루 보지 않기" 기능 (localStorage 저장)
  - 닫기 버튼
-->
<script lang="ts">
	import { onMount, createEventDispatcher } from 'svelte';
	import type { PopupAnnouncement } from '$lib/apis/announcements';

	export let announcements: PopupAnnouncement[] = [];
	export let show = false;

	const dispatch = createEventDispatcher();

	let currentIndex = 0;

	// 오늘 날짜 키 생성
	const getTodayKey = () => {
		const today = new Date();
		return `popup_announcement_dismissed_${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
	};

	// 이전 날짜의 키 정리
	const cleanupOldKeys = () => {
		const todayKey = getTodayKey();
		const keysToRemove: string[] = [];

		for (let i = 0; i < localStorage.length; i++) {
			const key = localStorage.key(i);
			if (key && key.startsWith('popup_announcement_dismissed_') && key !== todayKey) {
				keysToRemove.push(key);
			}
		}

		keysToRemove.forEach((key) => localStorage.removeItem(key));
	};

	// ----- [2026-03-02] 오늘 하루 보지 않기 기능 확인 시작 -----
	// ■ 확인: isDismissedToday()가 정의되어 있지만 팝업 표시 시 체크하지 않음
	// ■ 현재 동작: 사용자가 "오늘 하루 보지 않기" 클릭 → localStorage 저장만 됨
	// ■ 주의: 다음 로그인 시 isDismissedToday() 체크가 빠져있어 팝업이 다시 표시됨
	// ----- [2026-03-02] 오늘 하루 보지 않기 기능 확인 종료 -----
	// 오늘 이미 닫았는지 확인
	const isDismissedToday = () => {
		return localStorage.getItem(getTodayKey()) === 'true';
	};

	// 오늘 하루 보지 않기
	const dismissToday = () => {
		localStorage.setItem(getTodayKey(), 'true');
		closeModal();
	};

	// 모달 닫기
	const closeModal = () => {
		show = false;
		dispatch('close');
	};

	// 다음 공지
	const nextAnnouncement = () => {
		if (announcements.length > 1) {
			currentIndex = (currentIndex + 1) % announcements.length;
		}
	};

	// 이전 공지
	const prevAnnouncement = () => {
		if (announcements.length > 1) {
			currentIndex = (currentIndex - 1 + announcements.length) % announcements.length;
		}
	};

	// 특정 공지로 이동
	const goToAnnouncement = (index: number) => {
		currentIndex = index;
	};

	// 날짜 포맷팅
	const formatDate = (timestamp: number): string => {
		const date = new Date(timestamp * 1000);
		return date.toLocaleDateString('ko-KR', {
			year: 'numeric',
			month: 'long',
			day: 'numeric'
		});
	};

	// ----- [2026-02-05] RichTextInput HTML 콘텐츠 렌더링 함수 시작 -----
	// RichTextInput에서 출력된 HTML을 안전하게 렌더링
	const renderContentWithImages = (content: string): string => {
		if (!content) return '';

		// RichTextInput은 이미 HTML을 출력하므로 기본적으로 그대로 사용
		// 단, 위험한 스크립트 태그와 이벤트 핸들러만 제거
		let safeContent = content
			.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
			.replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')
			.replace(/on\w+\s*=\s*[^\s>]+/gi, '');

		// 기존 [IMAGE:base64] 형식도 지원 (하위 호환성)
		safeContent = safeContent.replace(
			/\[IMAGE:(data:image\/[^;]+;base64,[^\]]+)\]/g,
			'<img src="$1" alt="공지 이미지" class="max-w-full h-auto rounded-lg my-2 border border-gray-200 dark:border-gray-700" style="max-height: 300px; object-fit: contain;" />'
		);

		return safeContent;
	};
	// ----- [2026-02-05] RichTextInput HTML 콘텐츠 렌더링 함수 종료 -----

	onMount(() => {
		// 이전 날짜의 localStorage 키 정리
		cleanupOldKeys();
		console.log('[PopupModal] 컴포넌트 마운트됨, show:', show, ', announcements:', announcements?.length || 0);
	});

	// show 값 변경 감지
	$: {
		console.log('[PopupModal] show 값 변경:', show, ', announcements:', announcements?.length || 0);
		if (show && announcements.length > 0) {
			console.log('[PopupModal] 모달 표시 조건 충족!');
		}
	}
</script>

{#if show && announcements.length > 0}
	<!-- svelte-ignore a11y-click-events-have-key-events -->
	<!-- svelte-ignore a11y-no-static-element-interactions -->
	<div
		class="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm"
		style="z-index: 99999 !important; position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important; display: flex !important;"
		on:click|self={closeModal}
	>
		<div class="relative w-full max-w-5xl mx-4 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl overflow-hidden">
			<!-- 헤더 -->
			<div class="flex items-center justify-between px-8 py-5 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-500 to-blue-600">
				<div class="flex items-center space-x-3">
					<svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
					</svg>
					<span class="text-xl font-semibold text-white">공지사항</span>
				</div>
				<button
					class="text-white/80 hover:text-white transition p-2"
					on:click={closeModal}
				>
					<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
					</svg>
				</button>
			</div>

			<!-- 공지 컨텐츠 -->
			<div class="relative">
				{#each announcements as announcement, index}
					<div
						class="transition-all duration-300 ease-in-out {index === currentIndex ? 'opacity-100' : 'opacity-0 absolute inset-0 pointer-events-none'}"
					>
						<div class="p-8">
							<!-- 제목 -->
							<h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-4">
								{announcement.title}
							</h3>

							<!-- 작성 정보 -->
							<div class="flex items-center space-x-3 text-sm text-gray-500 dark:text-gray-400 mb-4">
								<span class="flex items-center">
									<svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
									</svg>
									{announcement.author}
								</span>
								<span>|</span>
								<span class="flex items-center">
									<svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
									</svg>
									{formatDate(announcement.start_date)} ~ {formatDate(announcement.end_date)}
								</span>
							</div>

							<!-- ----- [2026-02-04] 이미지 표시 (멀티모달) 시작 ----- -->
							{#if announcement.image_url}
								<div class="mb-4">
									<img
										src={announcement.image_url}
										alt={announcement.title}
										class="w-full max-h-48 object-contain rounded-lg border border-gray-200 dark:border-gray-700"
									/>
								</div>
							{/if}
							<!-- ----- [2026-02-04] 이미지 표시 (멀티모달) 종료 ----- -->

							<!-- ----- [2026-02-05] RichTextInput HTML 콘텐츠 렌더링 시작 ----- -->
							<div class="prose prose-base dark:prose-invert max-w-none text-gray-700 dark:text-gray-300 leading-relaxed max-h-[500px] overflow-y-auto announcement-content">
								{@html renderContentWithImages(announcement.content)}
							</div>
							<style>
								.announcement-content img {
									max-width: 100%;
									height: auto;
									border-radius: 0.5rem;
									margin: 0.5rem 0;
								}
								.announcement-content table {
									width: 100%;
									border-collapse: collapse;
									margin: 0.5rem 0;
								}
								.announcement-content th,
								.announcement-content td {
									border: 1px solid #e5e7eb;
									padding: 0.5rem;
									text-align: left;
								}
								.announcement-content th {
									background-color: #f3f4f6;
								}
								:global(.dark) .announcement-content th,
								:global(.dark) .announcement-content td {
									border-color: #374151;
								}
								:global(.dark) .announcement-content th {
									background-color: #1f2937;
								}
							</style>
							<!-- ----- [2026-02-05] RichTextInput HTML 콘텐츠 렌더링 종료 ----->
						</div>
					</div>
				{/each}

				<!-- 네비게이션 버튼 (2개 이상일 때만 표시) -->
				{#if announcements.length > 1}
					<button
						class="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-white/90 dark:bg-gray-800/90 rounded-full shadow-lg hover:bg-white dark:hover:bg-gray-700 hover:scale-110 transition-all"
						on:click={prevAnnouncement}
						title="이전 공지"
					>
						<svg class="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
						</svg>
					</button>
					<button
						class="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-white/90 dark:bg-gray-800/90 rounded-full shadow-lg hover:bg-white dark:hover:bg-gray-700 hover:scale-110 transition-all"
						on:click={nextAnnouncement}
						title="다음 공지"
					>
						<svg class="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
						</svg>
					</button>
				{/if}
			</div>

			<!-- 인디케이터 (2개 이상일 때만 표시) -->
			{#if announcements.length > 1}
				<div class="flex justify-center items-center space-x-3 py-3 border-t border-gray-200 dark:border-gray-700">
					{#each announcements as _, index}
						<button
							class="w-3 h-3 rounded-full transition-all duration-300 {index === currentIndex ? 'bg-blue-500 scale-125' : 'bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500 hover:scale-110'}"
							on:click={() => goToAnnouncement(index)}
							title="공지 {index + 1}"
						/>
					{/each}
				</div>
			{/if}

			<!-- 푸터 -->
			<div class="flex items-center justify-between px-8 py-4 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
				<button
					class="text-base text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition flex items-center"
					on:click={dismissToday}
				>
					<svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
					</svg>
					오늘 하루 보지 않기
				</button>
				<div class="text-base text-gray-500 dark:text-gray-400 font-medium">
					{currentIndex + 1} / {announcements.length}
				</div>
			</div>
		</div>
	</div>
{/if}
<!-- ----- [2026-02-04] 팝업 공지 컴포넌트 종료 ----- -->
